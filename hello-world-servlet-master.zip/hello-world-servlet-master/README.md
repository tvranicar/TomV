# hello-world-servlet
HelloWorld Servlet example with corresponding Dockerfile
